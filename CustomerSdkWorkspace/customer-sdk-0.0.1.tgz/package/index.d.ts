import * as i0 from '@angular/core';
import { EventEmitter, InjectionToken } from '@angular/core';
import { Observable } from 'rxjs';

declare class CustomerSdk {
    static ɵfac: i0.ɵɵFactoryDeclaration<CustomerSdk, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CustomerSdk, "lib-customer-sdk", never, {}, {}, never, never, true, never>;
}

interface PremiumRequest {
    InwardDate: string;
    ApplicationNo: string;
    Source: string;
    CustomerID: string;
    AddField: {
        Dummy: {
            DummyName: string;
            DummyValue: string;
        }[];
    };
    ApplicantDetails: {
        FirstName: string;
        LastName: string;
        DateOfBirth: string;
        Gender: string;
        Email: string;
        ContactNumber: string;
        City: string;
        State: string;
    };
    ProposerDetails: {
        IsProposersameasApplicant: boolean;
        FirstName: string;
        LastName: string;
        DateOfBirth: string;
        Gender: string;
        Email: string;
        ContactNumber: string;
        City: string;
        State: string;
    };
    ProductInfo: Record<string, string>;
    IsRiderOpt: boolean;
    Riders: {
        ridername: string;
        ridervalue: string;
    }[];
    FundStrategy: string;
    Funds: {
        fundname: string;
        fundvalue: string;
        fundpercentage: number;
    }[];
}

interface PremiumResponse {
    modalPremium: number;
    tax: number;
    sumAssured: number;
    modalPremiumwithTax: number;
    annualPremium: number;
    totalAnnualPremium: number;
    totalPremium: number;
    totalTAX: number;
    totalPremiumwithTax: number;
    message: string;
    status: string;
    transactionId: number;
}

declare class PremiumSdk {
    request: PremiumRequest;
    completed: EventEmitter<PremiumResponse>;
    private readonly premiumService;
    private readonly cdr;
    currentStep: number;
    loading: boolean;
    errorMessage: string;
    premiumResponse?: PremiumResponse;
    next(): void;
    back(): void;
    viewSummary(): void;
    returnToWebApp(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumSdk, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PremiumSdk, "lib-premium-sdk", never, { "request": { "alias": "request"; "required": true; }; }, { "completed": "completed"; }, never, never, true, never>;
}

declare const PREMIUM_API_URL: InjectionToken<string>;
declare class PremiumService {
    private readonly http;
    private readonly apiUrl;
    calculatePremium(request: PremiumRequest): Observable<PremiumResponse>;
    static ɵfac: i0.ɵɵFactoryDeclaration<PremiumService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PremiumService>;
}

interface ApplicantDetails {
    firstName: string;
    lastName: string;
    dateOfBirth: string;
    gender: string;
    email: string;
    contactNumber: string;
    city: string;
    state: string;
}

export { CustomerSdk, PREMIUM_API_URL, PremiumSdk, PremiumService };
export type { ApplicantDetails, PremiumRequest, PremiumResponse };
