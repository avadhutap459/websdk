import * as i0 from '@angular/core';
import { Component, InjectionToken, inject, Injectable, EventEmitter, ChangeDetectorRef, Output, Input } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule, DecimalPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';

class CustomerSdk {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: CustomerSdk, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.33", type: CustomerSdk, isStandalone: true, selector: "lib-customer-sdk", ngImport: i0, template: `
    <p>
      customer-sdk works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: CustomerSdk, decorators: [{
            type: Component,
            args: [{ selector: 'lib-customer-sdk', imports: [], template: `
    <p>
      customer-sdk works!
    </p>
  ` }]
        }] });

const PREMIUM_API_URL = new InjectionToken('PREMIUM_API_URL', {
    providedIn: 'root',
    factory: () => 'https://localhost:7126/api/Premium/calculate'
});
class PremiumService {
    http = inject(HttpClient);
    apiUrl = inject(PREMIUM_API_URL);
    calculatePremium(request) {
        return this.http.post(this.apiUrl, request);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PremiumService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PremiumService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PremiumService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

class PremiumSdk {
    request;
    completed = new EventEmitter();
    premiumService = inject(PremiumService);
    cdr = inject(ChangeDetectorRef);
    currentStep = 1;
    loading = false;
    errorMessage = '';
    premiumResponse;
    next() {
        if (this.currentStep < 2) {
            this.currentStep++;
        }
    }
    back() {
        if (this.currentStep > 1) {
            this.currentStep--;
        }
    }
    viewSummary() {
        if (this.loading) {
            return;
        }
        this.loading = true;
        this.errorMessage = '';
        this.premiumResponse = undefined;
        this.cdr.markForCheck();
        this.premiumService.calculatePremium(this.request).subscribe({
            next: (response) => {
                console.log('Premium API response:', response);
                this.premiumResponse = response;
                this.currentStep = 3;
                this.loading = false;
                // Notify Angular to refresh the view.
                this.cdr.markForCheck();
            },
            error: (error) => {
                console.error('Premium calculation failed:', error);
                this.errorMessage =
                    'Unable to calculate premium. Please try again.';
                this.loading = false;
                // Refresh the view to display the error.
                this.cdr.markForCheck();
            }
        });
    }
    returnToWebApp() {
        if (this.premiumResponse) {
            this.completed.emit(this.premiumResponse);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PremiumSdk, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.33", type: PremiumSdk, isStandalone: true, selector: "lib-premium-sdk", inputs: { request: "request" }, outputs: { completed: "completed" }, ngImport: i0, template: "<div class=\"premium-container\">\r\n  <header class=\"premium-header\">\r\n    SUD LIFE SARAL JEEVAN BIMA\r\n  </header>\r\n\r\n  <nav class=\"stepper\">\r\n    <span [class.active]=\"currentStep >= 1\">\r\n      1. Basic Information\r\n    </span>\r\n\r\n    <span [class.active]=\"currentStep >= 2\">\r\n      2. Product Information\r\n    </span>\r\n\r\n    <span [class.active]=\"currentStep >= 3\">\r\n      3. Summary\r\n    </span>\r\n  </nav>\r\n\r\n  <section *ngIf=\"currentStep === 1\">\r\n    <h2>Basic Information</h2>\r\n    <p>Confirm the applicant and proposer details.</p>\r\n\r\n    <button type=\"button\" (click)=\"next()\">NEXT</button>\r\n  </section>\r\n\r\n  <section *ngIf=\"currentStep === 2\">\r\n    <h2>Product Information</h2>\r\n    <p>Confirm the product, policy term and sum assured.</p>\r\n\r\n    <button type=\"button\" (click)=\"back()\">BACK</button>\r\n\r\n    <button\r\n      type=\"button\"\r\n      (click)=\"viewSummary()\"\r\n      [disabled]=\"loading\">\r\n      {{ loading ? 'Calculating...' : 'VIEW SUMMARY' }}\r\n    </button>\r\n  </section>\r\n\r\n  <section *ngIf=\"currentStep === 3 && premiumResponse as response\">\r\n  <h2>Premium Summary</h2>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Annual Premium</span>\r\n    <strong>\r\n      {{ response.annualPremium | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Installment Premium</span>\r\n    <strong>\r\n      {{ response.modalPremium | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Tax</span>\r\n    <strong>\r\n      {{ response.tax | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <p>{{ response.message }}</p>\r\n\r\n  <button type=\"button\" (click)=\"returnToWebApp()\">\r\n    RETURN TO WEB APP\r\n  </button>\r\n</section>\r\n\r\n  <p *ngIf=\"loading\">Please wait while the premium is calculated...</p>\r\n\r\n  <p *ngIf=\"errorMessage\" class=\"error\">\r\n    {{ errorMessage }}\r\n  </p>\r\n</div>", styles: [":host{display:block;font-family:Arial,sans-serif;color:#262626}.premium-container{border:1px solid #ddd;border-radius:8px;overflow:hidden;background:#fff}.premium-header{background:#c8102e;color:#fff;padding:18px 24px;font-size:20px;font-weight:700}.stepper{display:flex;flex-wrap:wrap;gap:24px;padding:18px 24px;border-bottom:1px solid #ddd}.stepper span{color:#777}.stepper .active{color:#c8102e;font-weight:700}section{padding:24px}button{padding:11px 20px;border:0;border-radius:4px;margin:8px 8px 8px 0;background:#c8102e;color:#fff;cursor:pointer}button:disabled{opacity:.6;cursor:not-allowed}.premium-card{display:inline-flex;flex-direction:column;gap:8px;padding:16px;margin:8px;min-width:160px;border:1px solid #ddd;border-radius:6px}.error{color:#b00020;padding:0 24px 16px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "pipe", type: i1.DecimalPipe, name: "number" }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.33", ngImport: i0, type: PremiumSdk, decorators: [{
            type: Component,
            args: [{ selector: 'lib-premium-sdk', standalone: true, imports: [CommonModule, DecimalPipe], template: "<div class=\"premium-container\">\r\n  <header class=\"premium-header\">\r\n    SUD LIFE SARAL JEEVAN BIMA\r\n  </header>\r\n\r\n  <nav class=\"stepper\">\r\n    <span [class.active]=\"currentStep >= 1\">\r\n      1. Basic Information\r\n    </span>\r\n\r\n    <span [class.active]=\"currentStep >= 2\">\r\n      2. Product Information\r\n    </span>\r\n\r\n    <span [class.active]=\"currentStep >= 3\">\r\n      3. Summary\r\n    </span>\r\n  </nav>\r\n\r\n  <section *ngIf=\"currentStep === 1\">\r\n    <h2>Basic Information</h2>\r\n    <p>Confirm the applicant and proposer details.</p>\r\n\r\n    <button type=\"button\" (click)=\"next()\">NEXT</button>\r\n  </section>\r\n\r\n  <section *ngIf=\"currentStep === 2\">\r\n    <h2>Product Information</h2>\r\n    <p>Confirm the product, policy term and sum assured.</p>\r\n\r\n    <button type=\"button\" (click)=\"back()\">BACK</button>\r\n\r\n    <button\r\n      type=\"button\"\r\n      (click)=\"viewSummary()\"\r\n      [disabled]=\"loading\">\r\n      {{ loading ? 'Calculating...' : 'VIEW SUMMARY' }}\r\n    </button>\r\n  </section>\r\n\r\n  <section *ngIf=\"currentStep === 3 && premiumResponse as response\">\r\n  <h2>Premium Summary</h2>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Annual Premium</span>\r\n    <strong>\r\n      {{ response.annualPremium | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Installment Premium</span>\r\n    <strong>\r\n      {{ response.modalPremium | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <div class=\"premium-card\">\r\n    <span>Tax</span>\r\n    <strong>\r\n      {{ response.tax | number:'1.0-2' }}\r\n    </strong>\r\n  </div>\r\n\r\n  <p>{{ response.message }}</p>\r\n\r\n  <button type=\"button\" (click)=\"returnToWebApp()\">\r\n    RETURN TO WEB APP\r\n  </button>\r\n</section>\r\n\r\n  <p *ngIf=\"loading\">Please wait while the premium is calculated...</p>\r\n\r\n  <p *ngIf=\"errorMessage\" class=\"error\">\r\n    {{ errorMessage }}\r\n  </p>\r\n</div>", styles: [":host{display:block;font-family:Arial,sans-serif;color:#262626}.premium-container{border:1px solid #ddd;border-radius:8px;overflow:hidden;background:#fff}.premium-header{background:#c8102e;color:#fff;padding:18px 24px;font-size:20px;font-weight:700}.stepper{display:flex;flex-wrap:wrap;gap:24px;padding:18px 24px;border-bottom:1px solid #ddd}.stepper span{color:#777}.stepper .active{color:#c8102e;font-weight:700}section{padding:24px}button{padding:11px 20px;border:0;border-radius:4px;margin:8px 8px 8px 0;background:#c8102e;color:#fff;cursor:pointer}button:disabled{opacity:.6;cursor:not-allowed}.premium-card{display:inline-flex;flex-direction:column;gap:8px;padding:16px;margin:8px;min-width:160px;border:1px solid #ddd;border-radius:6px}.error{color:#b00020;padding:0 24px 16px}\n"] }]
        }], propDecorators: { request: [{
                type: Input,
                args: [{ required: true }]
            }], completed: [{
                type: Output
            }] } });

/*
 * Public API Surface of customer-sdk
 */

/**
 * Generated bundle index. Do not edit.
 */

export { CustomerSdk, PREMIUM_API_URL, PremiumSdk, PremiumService };
//# sourceMappingURL=customer-sdk.mjs.map
